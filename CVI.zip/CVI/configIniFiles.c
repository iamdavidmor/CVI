//==============================================================================
//
// Title:		configIniFiles
// Purpose:		A short description of the library.
//
// Created on:	11/08/2021 at 07:55:11 p. m. by .
// Copyright:	. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <utility.h>
#include "configIniFiles.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

//==============================================================================
// Static functions

//==============================================================================
// Global variables

//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?
int __declspec(dllexport) __stdcall read_iniFile(char *iniFile, char *section, char *tag, BOOL str0_num1, char stringValue[1024], double *numericValue, char status[1024])
{
	int error = 0;
	char *dummyStringValue = 0;
	IniText iniHandle = NULL;
	
	// Lock the function.
	//EnterCriticalSection(&DUT_Lab_Lock);

	// Set default values.
	strcpy(stringValue, "");
	*numericValue = -999.0;
	
	// Verify if iniFile exist.
	if(!FileExists(iniFile,0)){
		sprintf(status, "Config File: %s does NOT exist", iniFile);
		error = 1;
		goto Error;
	}
	
	// Creates a Handle for the iniFile.
	iniHandle = Ini_New (0);
	if(iniHandle == 0){
		sprintf(status, "Not enough memory to open Config File: %s", iniFile);
		error = 1;
		goto Error;
	}	
	
	// Handles the Error, if any
	if(Ini_ReadFromFile (iniHandle, iniFile) < 0){
		sprintf(status, "Error reading file: %s", iniFile);
		error = 1;
		goto Error;
	}

	// Verify Section exists.
	if(Ini_SectionExists (iniHandle, section) == 0){
		sprintf(status, "Section [%s] does NOT exist on file %s", section, iniFile);
		error = 1;
		goto Error;
	}
	
	// Verify that Tag <Languaje> Exist.
	 if(Ini_ItemExists (iniHandle, section, tag) == 0){
		sprintf(status, "Tag <%s> on Section [%s] does NOT exist on file %s", tag, section, iniFile);
		error = 1;
		goto Error;
	 }

	 if(str0_num1){
		if(Ini_GetDouble (iniHandle, section, tag, &(*numericValue)) < 1){
			sprintf(status, "Error getting Tag <%s> from Section [%s] on Config File %s", section, tag, iniFile);
			error = 1;
			goto Error;
		}
	 }
	 else{
		if(Ini_GetPointerToRawString (iniHandle, section, tag, &dummyStringValue) < 1){
			sprintf(status, "Error getting Tag <Type> from Section [%s] on Config File %s", section, iniFile);
			error = 1;
			goto Error;
		}
		strcpy(stringValue, dummyStringValue);
	 }
	 
Error:
	 if(!error)
		strcpy(status, "Success");
	 
	if(iniHandle != NULL){
		Ini_Dispose (iniHandle);
		iniHandle = NULL;
	}	

	// Unlock the Function.
	//LeaveCriticalSection(&DUT_Lab_Lock);

	return error;
}

int __declspec(dllexport) __stdcall write_iniFile(char *iniFile, char *section, char *tag, BOOL str0_num1, char *stringValue, double numericValue, char status[1024])
{
	int error = 0;
	IniText iniHandle = NULL;
	
	// Lock the function.
	//EnterCriticalSection(&DUT_Lab_Lock);

	// Verify if iniFile exist.
	if(!FileExists(iniFile,0)){
		sprintf(status, "Config File: %s does NOT exist", iniFile);
		error = 1;
		goto Error;
	}
	
	// Creates a Handle for the iniFile.
	iniHandle = Ini_New (0);
	if(iniHandle == 0){
		sprintf(status, "Not enough memory to open Config File: %s", iniFile);
		error = 1;
		goto Error;
	}	
	
	// Handles the Error, if any
	if(Ini_ReadFromFile (iniHandle, iniFile) < 0){
		sprintf(status, "Error reading file: %s", iniFile);
		error = 1;
		goto Error;
	}
	
	if(str0_num1){
		if(Ini_PutDouble (iniHandle, section, tag, numericValue)){
			sprintf(status, "Error setting Tag <%s> on Section [%s] on Config File %s", section, tag, iniFile);
			error = 1;
			goto Error;
		}
	 }
	 else{
		if(Ini_PutRawString (iniHandle, section, tag, stringValue)){
			sprintf(status, "Error setting Tag <Type> on Section [%s] on Config File %s", section, iniFile);
			error = 1;
			goto Error;
		}
	 }

	if(Ini_WriteToFile (iniHandle, iniFile) < 0){
		sprintf(status, "Error Writing Tag <%s> on Section [%s] on file %s", tag, section, iniFile);
		error = 1;
		goto Error;
	}

Error:	
	if(!error)
		strcpy(status, "Success");
	 
	if(iniHandle != NULL){
		Ini_Dispose (iniHandle);
		iniHandle = NULL;
	}	

	// Unlock the Function.
	//LeaveCriticalSection(&DUT_Lab_Lock);

	return error;
}

//==============================================================================
// DLL main entry-point functions

int __stdcall DllMain (HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	switch (fdwReason) {
		case DLL_PROCESS_ATTACH:
			if (InitCVIRTE (hinstDLL, 0, 0) == 0)
				return 0;	  /* out of memory */
			break;
		case DLL_PROCESS_DETACH:
			CloseCVIRTE ();
			break;
	}
	
	return 1;
}

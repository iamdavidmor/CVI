//==============================================================================
//
// Title:		configIniFiles
// Purpose:		A short description of the interface.
//
// Created on:	11/08/2021 at 07:55:11 p. m. by .
// Copyright:	. All Rights Reserved.
//
//==============================================================================

#ifndef __configIniFiles_H__
#define __configIniFiles_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"
#include <inifile.h>
//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// External variables

//==============================================================================
// Global functions

int __declspec(dllexport) __stdcall write_iniFile(char *iniFile, char *section, char *tag, BOOL str0_num1, char *stringValue, double numericValue, char status[1024]);
int __declspec(dllexport) __stdcall read_iniFile(char *iniFile, char *section, char *tag, BOOL str0_num1, char stringValue[1024], double *numericValue, char status[1024]);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __configIniFiles_H__ */
